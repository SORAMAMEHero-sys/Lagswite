# そら豆 Auto Clicker (Soramame Auto Clicker)

**Amazon Fire HD 8 / Fire OS 8 (Android 11 API 30) 最適化超高速オートクリッカー**

## ビルドコマンド
```bash
cd android
./gradlew assembleDebug
```

生成場所:
`android/app/build/outputs/apk/debug/app-debug.apk`
