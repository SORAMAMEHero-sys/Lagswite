@echo off
echo ========================================================
echo  Soramame Auto Clicker - Fire HD 8 APK Builder (Windows)
echo ========================================================
where java >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Java (JDK 17 or higher) is not installed or not in PATH.
    echo Please install OpenJDK 17: https://adoptium.net/
    pause
    exit /b 1
)

echo Building Debug APK with Gradle...
call gradlew.bat assembleDebug

if %errorlevel% equ 0 (
    echo.
    echo ========================================================
    echo  SUCCESS: APK generated at:
    echo  app\build\outputs\apk\debug\app-debug.apk
    echo ========================================================
    echo.
    echo To install on your Fire HD 8 tablet via ADB, run:
    echo   adb install -r app\build\outputs\apk\debug\app-debug.apk
) else (
    echo [ERROR] Build failed. Please check the logs above.
)
pause
