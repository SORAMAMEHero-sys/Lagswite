#!/bin/bash
set -e
echo "========================================================"
echo " Soramame Auto Clicker - Fire HD 8 APK Builder (macOS/Linux)"
echo "========================================================"

if ! command -v java &> /dev/null; then
    echo "[ERROR] Java (JDK 17+) is required. Please install OpenJDK 17."
    exit 1
fi

chmod +x gradlew
echo "Building Debug APK with Gradle..."
./gradlew assembleDebug

echo ""
echo "========================================================"
echo " SUCCESS: APK generated at:"
echo " app/build/outputs/apk/debug/app-debug.apk"
echo "========================================================"
echo ""
echo "To install on your Fire HD 8 tablet via ADB, run:"
echo "  adb install -r app/build/outputs/apk/debug/app-debug.apk"
