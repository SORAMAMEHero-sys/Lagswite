@echo off
echo ========================================================
echo  Fire OS 8 Auto Permission Grant Tool for Soramame Clicker
echo ========================================================
adb devices
echo Granting Accessibility Service permission...
adb shell settings put secure enabled_accessibility_services com.soramame.autoclicker/com.soramame.autoclicker.service.SoramameAccessibilityService
adb shell settings put secure accessibility_enabled 1

echo Granting System Alert Window (Overlay) permission...
adb shell appops set com.soramame.autoclicker SYSTEM_ALERT_WINDOW allow

echo Adding to Battery Optimization Whitelist...
adb shell dumpsys deviceidle whitelist +com.soramame.autoclicker

echo DONE! All permissions granted on Fire HD 8.
pause
