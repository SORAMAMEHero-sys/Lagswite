package com.soramame.autoclicker.data

import android.content.Context
import android.content.SharedPreferences

data class ClickerConfig(
    val intervalMs: Double = 1.0,
    val isUnlimited: Boolean = true,
    val repeatCount: Int = 100,
    val targetX: Float = 640f,
    val targetY: Float = 400f,
    val pressDurationMs: Long = 1L
)

class ClickerPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("soramame_clicker_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_INTERVAL_MS = "interval_ms"
        private const val KEY_IS_UNLIMITED = "is_unlimited"
        private const val KEY_REPEAT_COUNT = "repeat_count"
        private const val KEY_TARGET_X = "target_x"
        private const val KEY_TARGET_Y = "target_y"
        private const val KEY_PRESS_DURATION = "press_duration"
    }

    fun loadConfig(): ClickerConfig {
        return ClickerConfig(
            intervalMs = prefs.getString(KEY_INTERVAL_MS, "1.0")?.toDoubleOrNull() ?: 1.0,
            isUnlimited = prefs.getBoolean(KEY_IS_UNLIMITED, true),
            repeatCount = prefs.getInt(KEY_REPEAT_COUNT, 100),
            targetX = prefs.getFloat(KEY_TARGET_X, 640f),
            targetY = prefs.getFloat(KEY_TARGET_Y, 400f),
            pressDurationMs = prefs.getLong(KEY_PRESS_DURATION, 1L)
        )
    }

    fun saveConfig(config: ClickerConfig) {
        prefs.edit()
            .putString(KEY_INTERVAL_MS, config.intervalMs.toString())
            .putBoolean(KEY_IS_UNLIMITED, config.isUnlimited)
            .putInt(KEY_REPEAT_COUNT, config.repeatCount)
            .putFloat(KEY_TARGET_X, config.targetX)
            .putFloat(KEY_TARGET_Y, config.targetY)
            .putLong(KEY_PRESS_DURATION, config.pressDurationMs)
            .apply()
    }
}