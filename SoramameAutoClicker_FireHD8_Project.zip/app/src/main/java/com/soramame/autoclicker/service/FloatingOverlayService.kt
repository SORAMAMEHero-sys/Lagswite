package com.soramame.autoclicker.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.soramame.autoclicker.MainActivity
import com.soramame.autoclicker.R
import com.soramame.autoclicker.data.ClickerConfig
import com.soramame.autoclicker.data.ClickerPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var preferences: ClickerPreferences
    private var config: ClickerConfig = ClickerConfig()

    private var controlPanelView: View? = null
    private var targetPointerView: View? = null

    private var btnPlayPause: Button? = null
    private var tvStats: TextView? = null
    private var tvSpeedDiff: TextView? = null

    private val serviceScope = CoroutineScope(Dispatchers.Default)
    private var clickingJob: Job? = null
    private var isClicking = false

    private var totalClicksExecuted = 0
    private var clickStartTime = 0L
    private var lastSecondClicks = 0
    private var lastSecondTimestamp = 0L
    private var currentMeasuredTps = 0.0

    companion object {
        const val ACTION_START = "com.soramame.autoclicker.ACTION_START"
        const val ACTION_STOP = "com.soramame.autoclicker.ACTION_STOP"
        private const val CHANNEL_ID = "soramame_overlay_channel"
        private const val NOTIFICATION_ID = 2024
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        preferences = ClickerPreferences(this)
        config = preferences.loadConfig()

        startForegroundServiceNotification()
        createTargetPointerOverlay()
        createControlPanelOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopClicking()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundServiceNotification() {
        val channelName = "Soramame Overlay Service"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                channelName,
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_service_notification_title))
            .setContentText(getString(R.string.overlay_service_notification_desc))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createTargetPointerOverlay() {
        val pointerSize = 130

        val pointerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#804CAF50"))
                setStroke(4, Color.parseColor("#FFFFFF"))
            }
            background = bg

            val label = TextView(context).apply {
                text = "Target"
                textSize = 10f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
            }
            addView(label)
        }

        val layoutParams = WindowManager.LayoutParams(
            pointerSize,
            pointerSize,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = config.targetX.toInt() - (pointerSize / 2)
            y = config.targetY.toInt() - (pointerSize / 2)
        }

        pointerLayout.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(pointerLayout, layoutParams)

                        config = config.copy(
                            targetX = layoutParams.x + (pointerSize / 2f),
                            targetY = layoutParams.y + (pointerSize / 2f)
                        )
                        preferences.saveConfig(config)
                        updateStatsDisplay()
                        return true
                    }
                }
                return false
            }
        })

        targetPointerView = pointerLayout
        windowManager.addView(pointerLayout, layoutParams)
    }

    private fun createControlPanelOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 24f
                setColor(Color.parseColor("#EE1B2E1E"))
                setStroke(2, Color.parseColor("#4CAF50"))
            }
            background = bg
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "そら豆 Auto Clicker"
            textSize = 13f
            setTextColor(Color.parseColor("#81C784"))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val btnClose = Button(this).apply {
            text = "✕"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                stopClicking()
                stopSelf()
            }
        }

        header.addView(title)
        header.addView(btnClose)
        root.addView(header)

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 10)
        }

        btnPlayPause = Button(this).apply {
            text = "開始 ▶"
            setTextColor(Color.WHITE)
            textSize = 13f
            val btnBg = GradientDrawable().apply {
                cornerRadius = 16f
                setColor(Color.parseColor("#2E7D32"))
            }
            background = btnBg
            setOnClickListener {
                if (isClicking) {
                    stopClicking()
                } else {
                    startClicking()
                }
            }
        }

        val btnOpenMain = Button(this).apply {
            text = "設定 ⚙"
            setTextColor(Color.parseColor("#C8E6C9"))
            textSize = 13f
            val btnBg = GradientDrawable().apply {
                cornerRadius = 16f
                setColor(Color.parseColor("#334E35"))
            }
            background = btnBg
            setOnClickListener {
                val intent = Intent(this@FloatingOverlayService, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                startActivity(intent)
            }
        }

        val paramBtn = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 85).apply {
            setMargins(8, 0, 8, 0)
        }
        buttonRow.addView(btnPlayPause, paramBtn)
        buttonRow.addView(btnOpenMain, paramBtn)
        root.addView(buttonRow)

        tvStats = TextView(this).apply {
            text = "座標: (${config.targetX.toInt()}, ${config.targetY.toInt()}) | 間隔: ${config.intervalMs}ms"
            textSize = 11f
            setTextColor(Color.parseColor("#E0E0E0"))
        }
        root.addView(tvStats)

        tvSpeedDiff = TextView(this).apply {
            text = "実測: -- cps (理論値: ${(1000.0 / config.intervalMs).toInt()} cps)"
            textSize = 10f
            setTextColor(Color.parseColor("#FFCC80"))
        }
        root.addView(tvSpeedDiff)

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 120
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(root, layoutParams)
                        return true
                    }
                }
                return false
            }
        })

        controlPanelView = root
        windowManager.addView(root, layoutParams)
    }

    private fun startClicking() {
        val a11y = SoramameAccessibilityService.sharedService
        if (a11y == null) {
            tvStats?.text = "アクセシビリティ未許可"
            return
        }

        isClicking = true
        totalClicksExecuted = 0
        clickStartTime = SystemClock.elapsedRealtime()
        lastSecondClicks = 0
        lastSecondTimestamp = clickStartTime
        btnPlayPause?.text = "停止 ⏸"

        clickingJob = serviceScope.launch {
            val intervalMs = config.intervalMs
            val targetX = config.targetX
            val targetY = config.targetY
            val isUnlimited = config.isUnlimited
            val maxCount = config.repeatCount

            while (isActive && isClicking) {
                if (!isUnlimited && totalClicksExecuted >= maxCount) {
                    withContext(Dispatchers.Main) {
                        stopClicking()
                        tvStats?.text = "完了 ($maxCount 回)"
                    }
                    break
                }

                a11y.dispatchTap(targetX, targetY, config.pressDurationMs) { success, _ ->
                    if (success) {
                        totalClicksExecuted++
                        lastSecondClicks++
                    }
                }

                val now = SystemClock.elapsedRealtime()
                val elapsedSinceLastSec = now - lastSecondTimestamp
                if (elapsedSinceLastSec >= 500) {
                    currentMeasuredTps = (lastSecondClicks * 1000.0) / elapsedSinceLastSec
                    lastSecondClicks = 0
                    lastSecondTimestamp = now
                    withContext(Dispatchers.Main) {
                        updateSpeedDiffDisplay()
                    }
                }

                if (intervalMs < 1.0) {
                    kotlinx.coroutines.yield()
                } else {
                    delay(intervalMs.toLong())
                }
            }
        }
    }

    private fun stopClicking() {
        isClicking = false
        clickingJob?.cancel()
        clickingJob = null
        btnPlayPause?.text = "開始 ▶"
        updateStatsDisplay()
    }

    private fun updateStatsDisplay() {
        tvStats?.text = String.format(
            Locale.getDefault(),
            "座標: (%d, %d) | 間隔: %.1fms | 累計: %d回",
            config.targetX.toInt(),
            config.targetY.toInt(),
            config.intervalMs,
            totalClicksExecuted
        )
    }

    private fun updateSpeedDiffDisplay() {
        val theoreticalTps = (1000.0 / config.intervalMs).toInt()
        val effectiveIntervalMs = if (currentMeasuredTps > 0) 1000.0 / currentMeasuredTps else 0.0
        tvSpeedDiff?.text = String.format(
            Locale.getDefault(),
            "実測: %.1f CPS (周期: %.1fms) vs 理論値: %d CPS",
            currentMeasuredTps,
            effectiveIntervalMs,
            theoreticalTps
        )
        updateStatsDisplay()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopClicking()
        controlPanelView?.let { windowManager.removeView(it) }
        targetPointerView?.let { windowManager.removeView(it) }
    }
}