package com.soramame.autoclicker.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SoramameAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "SoramameA11y"
        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        var sharedService: SoramameAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        sharedService = this
        _isRunning.value = true
        Log.i(TAG, "Soramame Accessibility Service Connected on Fire OS 8")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        _isRunning.value = false
    }

    override fun onDestroy() {
        super.onDestroy()
        sharedService = null
        _isRunning.value = false
    }

    fun dispatchTap(
        x: Float,
        y: Float,
        durationMs: Long = 1L,
        callback: ((Boolean, Long) -> Unit)? = null
    ) {
        val clickPath = Path().apply {
            moveTo(x, y)
        }

        // Android GestureDescription requires duration >= 1ms
        val safeDuration = durationMs.coerceAtLeast(1L)
        val stroke = GestureDescription.StrokeDescription(clickPath, 0L, safeDuration)
        val gesture = GestureDescription.Builder()
            .addStroke(stroke)
            .build()

        val startTime = SystemClock.elapsedRealtime()

        val success = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val latency = SystemClock.elapsedRealtime() - startTime
                    callback?.invoke(true, latency)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    val latency = SystemClock.elapsedRealtime() - startTime
                    Log.w(TAG, "Gesture cancelled: Gesture queue full or overlapping stroke")
                    callback?.invoke(false, latency)
                }
            },
            null
        )

        if (!success) {
            callback?.invoke(false, 0L)
        }
    }
}