package com.soramame.autoclicker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TabletAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.soramame.autoclicker.data.ClickerConfig
import com.soramame.autoclicker.data.ClickerPreferences
import com.soramame.autoclicker.service.FloatingOverlayService
import com.soramame.autoclicker.service.SoramameAccessibilityService
import com.soramame.autoclicker.ui.*
import com.soramame.autoclicker.ui.theme.SoramameAutoClickerTheme
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var preferences: ClickerPreferences
    private var configState = mutableStateOf(ClickerConfig())
    private var isA11yEnabledState = mutableStateOf(false)
    private var canOverlayState = mutableStateOf(false)
    private var isBatteryExemptState = mutableStateOf(false)
    private var isOverlayRunningState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = ClickerPreferences(this)
        configState.value = preferences.loadConfig()

        lifecycleScope.launch {
            SoramameAccessibilityService.isRunning.collectLatest { running ->
                isA11yEnabledState.value = running || checkAccessibilityEnabled()
            }
        }

        setContent {
            SoramameAutoClickerTheme {
                MainAppScreen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStates()
    }

    private fun updatePermissionStates() {
        canOverlayState.value = Settings.canDrawOverlays(this)
        isA11yEnabledState.value = checkAccessibilityEnabled()
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        isBatteryExemptState.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            powerManager?.isIgnoringBatteryOptimizations(packageName) == true
        } else {
            true
        }
    }

    private fun checkAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        for (service in enabledServices) {
            if (service.id.contains(packageName) && service.id.contains("SoramameAccessibilityService")) {
                return true
            }
        }
        return SoramameAccessibilityService.sharedService != null
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            try {
                startActivity(intent)
            } catch (e: Exception) {
                val genericIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                startActivity(genericIntent)
            }
        } else {
            Toast.makeText(this, "オーバーレイ権限は許可されています", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestAccessibilityPermission() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "ユーザー補助設定を開けませんでした", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestBatteryExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "バッテリー最適化設定を開けませんでした", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        if (!isA11yEnabledState.value) {
            requestAccessibilityPermission()
            return
        }

        if (isOverlayRunningState.value) {
            val intent = Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_STOP
            }
            startService(intent)
            isOverlayRunningState.value = false
        } else {
            val intent = Intent(this, FloatingOverlayService::class.java).apply {
                action = FloatingOverlayService.ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            isOverlayRunningState.value = true
            Toast.makeText(this, "フローティングパネルを開始しました", Toast.LENGTH_SHORT).show()
        }
    }

    @Composable
    private fun MainAppScreen() {
        var selectedTab by remember { mutableStateOf(0) }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = "ホーム") },
                        label = { Text("ホーム") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Speed, contentDescription = "速度測定") },
                        label = { Text("速度測定") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Security, contentDescription = "権限設定") },
                        label = { Text("権限設定") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.TabletAndroid, contentDescription = "Fire HD 8") },
                        label = { Text("Fire HD 8") }
                    )
                }
            }
        ) { paddingValues ->
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                color = MaterialTheme.colorScheme.background
            ) {
                when (selectedTab) {
                    0 -> HomeScreen(
                        config = configState.value,
                        isA11yEnabled = isA11yEnabledState.value,
                        canOverlay = canOverlayState.value,
                        isOverlayServiceRunning = isOverlayRunningState.value,
                        onSaveConfig = { newConfig ->
                            configState.value = newConfig
                            preferences.saveConfig(newConfig)
                            Toast.makeText(this@MainActivity, "設定を保存しました", Toast.LENGTH_SHORT).show()
                        },
                        onToggleOverlayService = { toggleOverlayService() },
                        onRequestA11yPermission = { requestAccessibilityPermission() },
                        onRequestOverlayPermission = { requestOverlayPermission() },
                        onNavigateToBenchmark = { selectedTab = 1 }
                    )
                    1 -> SpeedBenchmarkScreen()
                    2 -> PermissionsScreen(
                        isA11yEnabled = isA11yEnabledState.value,
                        canOverlay = canOverlayState.value,
                        isBatteryOptimizedExempt = isBatteryExemptState.value,
                        onRequestA11yPermission = { requestAccessibilityPermission() },
                        onRequestOverlayPermission = { requestOverlayPermission() },
                        onRequestBatteryExemption = { requestBatteryExemption() }
                    )
                    3 -> FireOsGuideScreen()
                }
            }
        }
    }
}